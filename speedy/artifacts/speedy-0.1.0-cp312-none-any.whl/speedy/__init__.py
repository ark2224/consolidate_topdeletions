from .speedy import *

__doc__ = speedy.__doc__
if hasattr(speedy, "__all__"):
    __all__ = speedy.__all__